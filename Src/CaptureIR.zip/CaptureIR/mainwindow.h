/*
 * CaptureIR - Infrared transceiver control application
 *
 * Copyright (c) Xen xen-re[at]tutanota.com
 */

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include "encodenecdialog.h"

#include "qcustomplot.h"
#include "ctqirsignal.h"
#include "TiqiaaUsb.h"

Q_DECLARE_METATYPE(std::vector<uint8_t>)

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);    
    ~MainWindow();
    void SetNecSignal(uint16_t IrCode);

signals:
    void on_signalPlotSet(std::vector<uint8_t> signal);

private slots:
    void horzScrollBarChanged(int value);
    void signalPlotSet(std::vector<uint8_t> signal);

    void on_actionOpen_triggered();

    void on_actionSave_triggered();

    void on_actionExit_triggered();

    void on_actionPlay_triggered();

    void on_actionCapture_triggered();

    void on_actionEncode_NEC_triggered();

    void on_actionDecode_NEC_triggered();

private:
    enum DevState {NoDevice, Idle, Receive, Send};
    Ui::MainWindow *ui;
    CTqIrSignal irSignal;
    TiqiaaUsbIr IrDevice;
    DevState IrDeviceState;
    EncodeNecDialog EncodeNecDlg;

    void signalPlotUpdate();
    void SetState(DevState st);
    static void OnIrDataReceived(uint8_t * data, int size, class TiqiaaUsbIr * IrCls, void * context);
};

#endif // MAINWINDOW_H
