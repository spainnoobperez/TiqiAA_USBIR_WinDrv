/*
 * CaptureIR - Infrared transceiver control application
 *
 * Copyright (c) Xen xen-re[at]tutanota.com
 */

#include "encodenecdialog.h"
#include "ui_encodenecdialog.h"

#include "mainwindow.h"

EncodeNecDialog::EncodeNecDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::EncodeNecDialog)
{
    ParentWin = parent;
    ui->setupUi(this);
}

EncodeNecDialog::~EncodeNecDialog()
{
    delete ui;
}

void EncodeNecDialog::on_buttonBox_accepted()
{
    bool ok;
    int code = ui->NecCodeLineEdit->text().toInt(&ok, 16);
    if (ok)((MainWindow *)ParentWin)->SetNecSignal(code);
}
