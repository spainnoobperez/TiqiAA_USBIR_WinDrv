/*
 * CaptureIR - Infrared transceiver control application
 *
 * Copyright (c) Xen xen-re[at]tutanota.com
 */

#include "mainwindow.h"
#include "ui_mainwindow.h"

#define SignalPlotDrawSize 70

const char * IrSignalFileFilter = "Tiqiaa signal (*.tir);;LIRC signal (*.lir)";

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    EncodeNecDlg(this)
{
    ui->setupUi(this);

    irSignal.WriteIrNecSignal(0);

    ui->signalPlot->addGraph();
    ui->signalPlot->yAxis->setRange(0, 1.25);
    ui->signalPlot->xAxis->setRange(0, SignalPlotDrawSize);
    ui->signalPlot->graph(0)->setPen(QPen(QColor(0, 0, 255)));
    ui->signalPlot->graph(0)->setBrush(QBrush(QColor(250, 120, 0)));

    qRegisterMetaType<std::vector<uint8_t>>();
    connect(ui->horizontalScrollBar, SIGNAL(valueChanged(int)), this, SLOT(horzScrollBarChanged(int)));
    connect(this, SIGNAL(on_signalPlotSet(std::vector<uint8_t>)), this, SLOT(signalPlotSet(std::vector<uint8_t>)), Qt::QueuedConnection);
    signalPlotUpdate();

    std::vector<std::string> DevList;
    IrDevice.IrRecvCallback = OnIrDataReceived;
    IrDevice.IrRecvCbContext = this;
    IrDeviceState = DevState::Idle;
    SetState(DevState::NoDevice);
    if (IrDevice.EnumDevices(DevList))
    {
        if (DevList.size() > 0)
        {
            if (IrDevice.Open(DevList[0].c_str()))
            {
                if (IrDevice.IsOpen()) SetState(DevState::Idle);
            }
        }
    }


}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::SetState(DevState st)
{
    if (st == IrDeviceState) return;
    IrDeviceState = st;
    switch (IrDeviceState)
    {
    case DevState::NoDevice:
        ui->statusBar->showMessage("No IR device");
    break;
    case DevState::Idle:
        ui->statusBar->showMessage("Ready");
    break;
    case DevState::Receive:
        ui->statusBar->showMessage("Receiving IR signal");
    break;
    case DevState::Send:
        ui->statusBar->showMessage("Sending IR signal");
    break;
    }
}

void MainWindow::horzScrollBarChanged(int value)
{
    ui->signalPlot->xAxis->setRange(value, ui->signalPlot->xAxis->range().size(), Qt::AlignLeft);
    ui->signalPlot->replot();
}

void MainWindow::SetNecSignal(uint16_t IrCode)
{
    irSignal.WriteIrNecSignal(IrCode);
    signalPlotUpdate();
}

void MainWindow::signalPlotSet(std::vector<uint8_t> signal)
{
    if (QThread::currentThread() == this->thread()){
        irSignal.FromTiqiaa(signal);
        signalPlotUpdate();
        SetState(DevState::Idle);
    } else {
        emit on_signalPlotSet(signal);
    }
}

void MainWindow::signalPlotUpdate()
{
    int max_x = irSignal.DrawSignal(ui->signalPlot->graph(0));
    if (max_x > SignalPlotDrawSize) max_x -= SignalPlotDrawSize;
        else max_x = SignalPlotDrawSize;
    ui->horizontalScrollBar->setRange(0, max_x);
    ui->signalPlot->replot();
}

void MainWindow::on_actionOpen_triggered()
{
    QString SelFlt;
    QString FileName = QFileDialog::getOpenFileName(this, "Open File", QString(), IrSignalFileFilter, &SelFlt);
    if ((FileName.isNull()) || (FileName.isEmpty())) return;
    QFile file(FileName);
    if (file.open(QIODevice::ReadOnly))
    {
        if (SelFlt[0] == 'L'){
            QByteArray sample = file.readAll();
            irSignal.FromLirc((uint32_t *)sample.data(), sample.size() / 4);
        } else {
            QByteArray sample = file.readAll();
            irSignal.FromTiqiaa((uint8_t *)sample.data(), sample.size());
        }
        file.close();        
    }
    signalPlotUpdate();
}

void MainWindow::on_actionSave_triggered()
{
    QString SelFlt;
    QString FileName = QFileDialog::getSaveFileName(this, "Save File", QString(), IrSignalFileFilter, &SelFlt);
    if ((FileName.isNull()) || (FileName.isEmpty())) return;
    QFile file(FileName);
    if (file.open(QIODevice::WriteOnly))
    {
        if (SelFlt[0] == 'L'){
            std::vector<uint32_t> sample = irSignal.ToLirc();
            file.write((char *)sample.data(), sample.size() * 4);
        } else {
            std::vector<uint8_t> sample = irSignal.ToTiqiaa();
            file.write((char *)sample.data(), sample.size());
        }
        file.close();
    }
}

void MainWindow::on_actionExit_triggered()
{
    this->close();
}

void MainWindow::on_actionPlay_triggered()
{
    if (IrDevice.IsOpen())
    {
        SetState(DevState::Send);
        std::vector<uint8_t> signal = irSignal.ToTiqiaa();
        IrDevice.SendIR(38000, signal.data(), signal.size());
        SetState(DevState::Idle);
    }
}

void MainWindow::on_actionCapture_triggered()
{
    if (IrDevice.IsOpen())
    {
        SetState(DevState::Receive);
        IrDevice.StartRecvIR();
    }
}

void MainWindow::on_actionEncode_NEC_triggered()
{
    EncodeNecDlg.show();
}

void MainWindow::on_actionDecode_NEC_triggered()
{
    uint16_t IrCode;
    uint32_t RawIrCode;
    if (irSignal.DecodeIrNecSignal(&IrCode, &RawIrCode))
    {
        QString message = QString::asprintf("NEC IR code : %04X Raw : %08X", IrCode, RawIrCode);
        MessageBoxA(0,message.toStdString().c_str(), "NEC Decoder", 0);
    } else {
        MessageBoxA(0, "Unable to decode signal", "NEC Decoder", 0);
    }
}

void MainWindow::OnIrDataReceived(uint8_t * data, int size, class TiqiaaUsbIr *, void * context)
{
    MainWindow * thisCls = (MainWindow *)context;
    std::vector<uint8_t> sample = std::vector<uint8_t>(data, data + size);
    thisCls->signalPlotSet(sample);
}
