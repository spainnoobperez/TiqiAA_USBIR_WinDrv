/*
 * CaptureIR - Infrared transceiver control application
 *
 * Copyright (c) Xen xen-re[at]tutanota.com
 */

#ifndef ENCODENECDIALOG_H
#define ENCODENECDIALOG_H

#include <QDialog>

namespace Ui {
class EncodeNecDialog;
}

class EncodeNecDialog : public QDialog
{
    Q_OBJECT

public:
    explicit EncodeNecDialog(QWidget *parent = 0);
    ~EncodeNecDialog();

private slots:
    void on_buttonBox_accepted();

private:
    Ui::EncodeNecDialog *ui;
    QWidget * ParentWin;
};

#endif // ENCODENECDIALOG_H
