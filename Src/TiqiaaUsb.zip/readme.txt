To use this software, default hidusb driver must be replaced to WinUsb driver.
Driver can be downloaded here:
https://gitlab.com/XenRE/tiqiaa-usb-ir/-/tree/master/Driver
